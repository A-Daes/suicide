
##Laboratorio #2 Dise;o de Lenguajes de Programacion
##Diego Javier Alvarez 14104
##Se utilizo la base de https://github.com/siddharthasahu/automata-from-regex
#### (En realidad se utilizo casi todo por razones de tiempo, pero lei todo lo posible para entender como se realizo.)
#### En el archivo "Lab2-INC.py" se encuentra lo que hice por mi cuenta. (Encontrar estados, simbolos, inicio y final)
## La funcion getSymbols() no estaba originalmente en la base, por lo que se utilizo la que hice en mi version.



from AutomataTheory import *
import sys

def main():
    inp = raw_input("Ingrese una expresion regular (Se aceptan + * ()): ")
    if len(sys.argv)>1:
        inp = sys.argv[1]
    print "Expresion ingresada: ", inp
    lang=getSymbols(inp)
    nfaObj = NFAfromRegex(inp)
    nfa = nfaObj.getNFA()
##    dfaObj = DFAfromNFA(nfa)
##    dfa = dfaObj.getDFA()
##    minDFA = dfaObj.getMinimisedDFA()
    print "\nNFA: "
    nfaObj.displayNFA()
    print "Simbolos: ", lang

## Parte de Lab 3
##    print "\nDFA: "
##    dfaObj.displayDFA()
##    print "\nMinimised DFA: "
##    dfaObj.displayMinimisedDFA()


if __name__  ==  '__main__':
    t = time.time()
    try:
        main()
    except BaseException as e:
        print "\nFailure:", e
    print "\nExecution time: ", time.time() - t, "seconds"
